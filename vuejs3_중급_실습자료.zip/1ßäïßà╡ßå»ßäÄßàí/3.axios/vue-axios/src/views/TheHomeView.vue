<script setup>

</script>

<template>
  <div class="container text-center">
    <h1 class="mt-5">MM Cafe에 오신걸 환영합니다.</h1>
  </div>
</template>

<style scoped></style>
