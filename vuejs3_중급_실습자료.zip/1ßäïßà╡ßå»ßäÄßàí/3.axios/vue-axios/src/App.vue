<script setup>
import TheHeadingNavbar from "./components/layout/TheHeadingNavbar.vue";


</script>

<template>
  <div>
    <TheHeadingNavbar />
    <router-view></router-view>
  </div>
</template>

<style scoped></style>
