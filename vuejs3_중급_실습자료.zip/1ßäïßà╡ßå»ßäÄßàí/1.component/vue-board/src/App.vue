<script setup>
import Navbar from "./components/layout/TheHeadingNavbar.vue";
import BoardView from "./views/AppBoardView.vue";
</script>

<template>
  <div>
    <Navbar />
    <BoardView />
  </div>
</template>

<style scoped></style>
