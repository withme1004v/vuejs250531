<script setup>
// import BoardDetail from "@/components/board/BoardDetail.vue";
import BoardList from "@/components/board/BoardList.vue";
// import BoardModify from "@/components/board/BoardModify.vue";
// import BoardWrite from "@/components/board/BoardWrite.vue";

</script>

<template>
  <div>
    <BoardList />
    <!-- <BoardDetail /> -->
    <!-- <BoardWrite /> -->
    <!-- <BoardModify /> -->
  </div>
</template>

<style>
mark.sky {
  background: linear-gradient(to top, #54fff9 20%, transparent 30%);
}
</style>
