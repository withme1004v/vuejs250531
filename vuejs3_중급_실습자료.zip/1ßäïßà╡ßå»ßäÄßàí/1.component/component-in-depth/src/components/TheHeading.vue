<script setup>

</script>

<template>
  <div>
    <h1><img alt="Vue logo" class="logo" src="@/assets/logo.svg" />Pass Props &amp; Emit Events</h1>
  </div>
</template>

<style scoped>
h1 {
  color: steelblue;
}

.logo {
  width: 50px;
  height: 50px;
}
</style>
