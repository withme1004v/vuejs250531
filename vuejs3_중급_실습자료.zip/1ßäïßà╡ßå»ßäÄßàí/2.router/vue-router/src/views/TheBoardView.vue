<script setup></script>

<template>
  <div class="container text-center mt-3">
    <h1>router05(중첩된 라우트)</h1>
    <div class="alert alert-info" role="alert">자유롭게 글쓰는 공간</div>
    <router-view></router-view>
  </div>
</template>

<style scoped></style>
