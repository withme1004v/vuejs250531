<script setup></script>

<template>
  <div class="container text-center mt-3">
    <h1>router06(props로 데이터 전달하기)</h1>
    <div class="alert alert-info" role="alert">자유롭게 글쓰는 공간</div>
    <router-view></router-view>
  </div>
</template>

<style scoped></style>
