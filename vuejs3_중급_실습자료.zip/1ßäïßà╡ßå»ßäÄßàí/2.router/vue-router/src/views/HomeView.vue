<script setup></script>

<template>
  <div class="container text-center mt-3">
    <h1>Vue Router !!!</h1>
    <div class="row justify-content-center">
      <div class="card m-3" style="width: 20rem">
        <img src="@/assets/logo.svg" class="card-img-top mx-auto my-2 w-75" alt="vue logo" />
        <div class="card-body">
          <p class="card-text">Vue Router 메인 페이지입니다.</p>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped></style>
