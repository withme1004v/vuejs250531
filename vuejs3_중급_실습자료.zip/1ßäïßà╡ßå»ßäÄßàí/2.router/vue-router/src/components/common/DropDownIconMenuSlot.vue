<script setup></script>

<template>
  <div>
    <slot name="icon"></slot>
    <slot name="label"></slot>
  </div>
</template>

<style scoped></style>
