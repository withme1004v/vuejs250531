<script setup></script>

<template>
  <div class="container text-center mt-3">
    <h1>router01(Router 기본)</h1>
    <div class="alert alert-primary" role="alert">사진 자랑하기</div>
  </div>
</template>

<style scoped></style>
