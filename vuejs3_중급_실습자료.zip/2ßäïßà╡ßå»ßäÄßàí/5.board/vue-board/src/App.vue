<script setup>
import Navbar from "./components/layout/TheHeadingNavbar.vue";
</script>

<template>
  <div>
    <Navbar />
    <router-view></router-view>
  </div>
</template>

<style scoped></style>
