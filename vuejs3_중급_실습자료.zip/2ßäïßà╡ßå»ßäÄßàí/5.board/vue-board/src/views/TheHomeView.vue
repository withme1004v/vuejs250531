<script setup>

</script>

<template>
  <div class="container text-center mt-5">
    <h1>MM Cafe에 오신것을 환영합니다.</h1>
  </div>
</template>

<style scoped></style>
